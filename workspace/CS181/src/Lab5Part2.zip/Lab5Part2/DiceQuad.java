/**
 * Lab 5
 * I pledge my honor that I have abided by the Stevens Honor System.
 * - David Kim
 */

package Lab5Part2;

/**
 * This will implement the Die_C class in the fourth die
 * @author davidkim
 *
 */

public class DiceQuad {
	protected static final String NAME = "David Kim";

    private Die die1;
    private Die die2;
    private Die die3;
    private Die_C die4; // fourth die is counterfeited

    public DiceQuad()
    { die1 = new Die(); 
      die2 = new Die(); 
      die3 = new Die();
      die4 = new Die_C ();
    }

    /**
     * this method will count how many '1's turn up when all four dice are rolled
     * @return how many '1' across four dice appear
     */
    private int countOne() {
    	int count = 0;
    	if (die1.getFaceValue() == 1){
    		count++;
    	}
    	if (die2.getFaceValue() == 1){
    		count++;
    	}
    	if (die3.getFaceValue() == 1){
    		count++;
    	}
    	if (die4.getFaceValue() == 1){
    		count++;
    	}
    	return count;
    }
    
    /**
     * rolls the four dice
     */
    public void roll()
    { die1.roll(); 
      die2.roll(); 
      die3.roll();
      die4.roll();
    }

    /**
     * boolean that tells if one '1' appears
     */
    public boolean oneOnes()
    { return (countOne() == 1); }

    /**
     * boolean that tells if two '1's appears
     */
    public boolean twoOnes()
    { return (countOne() == 2); }
    
    /**
     * boolean that tells if three '1's appears
     */
    public boolean threeOnes() 
    { return (countOne() == 3); }
    
    /**
     * boolean that tells if four '1's appears
     */
    public boolean fourOnes()
    { return (countOne() == 4); }
    
    /**
     * adds the values of all the four dice
     * @return the total value of the four dice
     */
    public int getDiceTotal()
    { return (die1.getFaceValue () + die2.getFaceValue () + die3.getFaceValue() + die4.getFaceValue()); }
    /**
     * displays the four dice values 
     */
    public String toString()
    { return "(" + die1 + "," + die2 + "," + die3 + "," + die4 + ")"; }
}
