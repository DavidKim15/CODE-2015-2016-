/**
 * Lab 5
 * I pledge my honor that I have abided by the Stevens Honor System.
 * - David Kim
 */

package Lab5Part2;

/**
 * This Die_C class will be for the counterfeited die. It will roll only one '1' within 10 rolls.
 * @author davidkim
 *
 */

public class Die_C {
	protected static final String NAME = "David Kim";

	public static final int MAX = 6;

    private int faceValue;
    private int countOne = 0;		//counts how many '1's were rolled
    private int countRolls = 0;		//counts how many rolls were done
    
    //empty constructor, initial value 1
    public Die_C() 
    { faceValue=1; }
    
    /**
     * implements roll() method for the counterfeited die
     * this means that it will roll exactly one '1' for every 10 rolls
     * @return faceValue, integer from 1 to 6
     */
    public int roll() {    	
    	faceValue = (int)(Math.random () * MAX) +1; //will roll as normal
    	countRolls++;								//counts the roll
    	
    	if (faceValue == 1 && countRolls <= 10) {	//if it's the first '1' within the interval
    		countOne ++;							//we will count the '1'
    	}
    	while (faceValue == 1 && countOne == 1){	//if there was already '1' in the interval, reroll
    		faceValue = (int)(Math.random () * MAX) +1;
    	}
    	if (countRolls > 10) {						//once we surpass the 10 rolls, reset the roll-counter to zero
    		countRolls = 0;
    		countOne = 0;
    	}
    	if (countRolls == 9 && countOne == 0){		//if there were 9 rolls and a '1' has still not popped out, then faceValue will yield one
    		faceValue = 1;
    	}
    	return faceValue;
    }

    //setter method
    public void setFaceValue(int faceValue) {
    	if (faceValue > 0 && faceValue <= MAX)
    		this.faceValue = faceValue;
    }

    //getter method
    public int getFaceValue() 
    {   return faceValue; }

    //return a String representation for the object
    public String toString()
    {   return Integer.toString(faceValue); }
}

