/*
 * I pledge that I have abided by the Stevens Honor System.
 * -David Kim
 */

package bookstore;

public class PaperbackBook extends Book {
	public static final String NAME = "David Kim";

	public PaperbackBook (String title, String author, int cost){
		super (title, author, cost, Medium.Paperback);			//constructor for paperback books
	}
	
	public String toString() {							// returns string representatino of paperback books
		return super.toString();
	}
	
	public boolean isForSale() {						// paperback books are always for sale so this returns true
		return true;
	}
}