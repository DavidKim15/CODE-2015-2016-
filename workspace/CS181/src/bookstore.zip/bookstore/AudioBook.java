/*
 * I pledge that I have abided by the Stevens Honor System.
 * -David Kim
 */

package bookstore;

public class AudioBook extends Book {
	public static final String NAME = "David Kim";

	private final int numDiscs;
	
	
	public AudioBook (String title, String author, int cost, int numDiscs) {
		super(title, author, cost, Medium.Audio);	//constructor for audiobooks
		this.numDiscs = numDiscs;
		
	}
	
	public String toString() {						// returns the string representation in the specified format
		return super.toString() + ": " + numDiscs + " discs.";
	}
	
	public boolean isForSale() {					// returns false because according the java documentation, audiobooks are never for sale
		return false;
	}
	
	public String getMedium() {						// returns the medium for audiobook in specified format
		return super.getMedium() +": "+numDiscs + " discs.";
	}
}
