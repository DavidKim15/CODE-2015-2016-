/*
 * I pledge that I have abided by the Stevens Honor System.
 * -David Kim
 */

package bookstore;

public class ElectronicBook extends Book {
	public static final String NAME = "David Kim";

	private final String theURL;
	
	public ElectronicBook (String title, String author, int cost, String theURL){
		super(title, author, cost, Medium.Electronic);		//constructor for electronic books
		this.theURL = theURL;
	}
	
	public String toString(){								//returns string representation of electronic book in specified format
		return super.toString() + " from "+ theURL + ".";
	}
	
	public boolean isForSale() {							//electronic books are never for sale so this will always return false
		return false;
	}
	
	public String getMedium() {							// returns the medium for Electronicbooks in specified format
		return super.getMedium() + ":" + theURL + ".";
	}
}
