/*
 * I pledge that I have abided by the Stevens Honor System.
 * -David Kim
 */

package bookstore;

/**
 * This is the abstract class for Book, starting the hiearchy of Book
 * @author davidkim
 *
 */
public abstract class Book {
	public static final String NAME = "David Kim";

	private final String author;
	private final int cost;
	private final Medium medium;
	private final String title;
	
	
	public Book (String title, String author, int cost, Medium medium) {
		this.title = title;
		this.author = author;
		this.cost = cost;
		this.medium = medium;
	}
	
	public abstract boolean isForSale();
	
	public String getAuthor() {				//returns author
		return author;
	}
	
	public double getCost() {				//returns the dd.cc format of 'cost' (cost is still in cents)
		double newCost = cost;
		newCost /= 100;
		return newCost;
	}
	
	public String getMedium() {				//returns the medium
		return ""+medium;
	}
	
	public String getTitle() {				//returns title
		return title;
	}
	
	public String toString() {				//returns string representation in the format specified
		return "\""+title+"\". \n\t"+author+".\n\t"+medium;
	}
}
