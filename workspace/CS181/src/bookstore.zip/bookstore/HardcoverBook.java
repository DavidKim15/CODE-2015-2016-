/*
 * I pledge that I have abided by the Stevens Honor System.
 * -David Kim
 */

package bookstore;

public class HardcoverBook extends Book {
	public static final String NAME = "David Kim";

	private final String coverMaterial;
	
	public HardcoverBook (String title, String author, int cost, String coverMaterial){
		super(title, author, cost, Medium.Hardcover);				//constructor for hardcover books
		this.coverMaterial = coverMaterial;
	}
	
	public String getCoverMaterial() {
		return coverMaterial;
	}
	
	public String getMedium() {								// returns the medium for hardcover books in specified format
		return super.getMedium() + " " + coverMaterial+".";
	}
	
	public boolean isForSale() {							// hardcover books are always for sale so this returns true
		return true;
	}
	
	public String toString() {								// returns string representation forhardcover book in specified format
		return super.toString() + " " + coverMaterial+".";
	}
}
